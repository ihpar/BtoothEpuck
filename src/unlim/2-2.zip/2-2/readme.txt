2 speakers random
2 listeners random
unlimited memory

r1 - 00:32:15.22
r2 - 00:34:39.75
r3 - 00:39:25.47
r4 - 00:46:04.32
r5 - 00:39:20.21